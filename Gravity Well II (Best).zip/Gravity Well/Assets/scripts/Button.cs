﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// Controls buttons which switch gravity and doors.
public class Button : MonoBehaviour
{
	public GameController gc;
	public Sprite pressedSprite;
	public Sprite depressedSprite;

	private bool pressed;

	void OnTriggerEnter2D(Collider2D coll)
	{
		if ((coll.gameObject.tag == "Player" || coll.gameObject.tag == "playerShot") && !pressed)
		{
			//PlayerController.grounded = false;
			gc.SwitchGravity();
			Press();
			if (coll.gameObject.tag == "playerShot")
			{ Destroy(coll.gameObject); }
		}
	}

	void Press()
	{
		pressed = true;
		GetComponent<SpriteRenderer>().sprite = pressedSprite;
		Invoke("Depress", 1f);
	}

	void Depress()
	{
		pressed = false;
		GetComponent<SpriteRenderer>().sprite = depressedSprite;
	}
}
