MatchMaker Readme
Zakary Olyarnik, Mark Takakjy
February 2017

INTRODUCTION:
You are an astronaut trapped on a space station where a black hole has just erupted!
Collect items as they float past to increase your mass and keep from being sucked in!

RUNNING THE GAME:
We have provided a Windows build (GravityWell.exe) and a WebGL build (index.html), both located in the Builds
subfolder, and both tested for validity.  The Windows build must be run with 1920x1080 resolution to display as
intended, due to the unpredictable way Unity's UI scales to different resolutions.  The web build is also set to
1920x1280, but should be run in fullscreen to properly display this way.

ASSETS:
All sprite images used were created by Mark.

"balloon_pop.wav" sound effect by Mike Koenig on SoundBible.com
"aww.wav" sound effect by phmiller42 of Freesound.org is used under a Creative Commons license.
"gibberish.wav" sound effect by xtrgamr of Freesound.org is used under a Creative Commons license.
"glass-break-2.wav" sound effect by Natty23 of Freesound.org is used under a Creative Commons license.
"Interference 01.wav" sound effect by Glitchedtones of Freesound.org is used under a Creative Commons license.
breaker noise (formerly "Kill Switch (Large Breaker Switch).wav" by Alvinwhatup2 of Freesound.org) is used under a Creative Commons license.
All other sound filed obtained through the Drexel database.

NOTES:
-The jump/hover mechanic was removed in an attempt to make the floating platforms more useful.  As the only way to move up, they are
now the only way to reach high-up enemies and satellite collectibles, plus allow for players to ride up and then float downwards to
collect the other collectibles more effectively.
-Both player mass and gravity are displayed so that the player always knows how close they are to floating upwards and can do risk
assessment on their moves and collection decisions.
-There is probably additional numbers-tweaking of various components required to better balance the game.  These include collectible spawn
time and distribution, platform spawn time, enemy spawn time and fire frequency, and how much mass is gained or lost by any given action.